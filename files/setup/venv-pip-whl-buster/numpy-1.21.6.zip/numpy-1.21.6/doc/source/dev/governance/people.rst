.. _governance-people:

Current steering council and institutional partners
===================================================

Steering council
----------------

* Sebastian Berg
* Ralf Gommers
* Charles Harris
* Stephan Hoyer
* Melissa Weber Mendonça
* Inessa Pawson
* Matti Picus
* Stéfan van der Walt
* Eric Wieser


Emeritus members
----------------

* Travis Oliphant -- project founder / emeritus leader (2005-2012)
* Alex Griffing (2015-2017)
* Marten van Kerkwijk (2017-2019)
* Allan Haldane (2015-2021)
* Nathaniel Smith (2012-2021)
* Julian Taylor (2013-2021)
* Pauli Virtanen (2008-2021)
* Jaime Fernández del Río (2014-2021)


NumFOCUS Subcommittee
---------------------

* Charles Harris
* Ralf Gommers
* Melissa Weber Mendonça
* Sebastian Berg
* External member: Thomas Caswell


Institutional Partners
----------------------

* UC Berkeley (Stéfan van der Walt, Sebastian Berg, Ross Barnowski)

* Quansight (Ralf Gommers, Melissa Weber Mendonça, Mars Lee, Matti Picus, Pearu Peterson)

